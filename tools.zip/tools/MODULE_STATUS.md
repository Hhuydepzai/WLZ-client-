# Module status

The UI and native state bridge are implemented for all 10 requested modules.

The runtime bridge intentionally does not pretend to alter the separate Minecraft process. A real game hook layer must be loaded inside the Minecraft process before module effects such as camera FOV, freelook, sprint, hitbox, brightness, FPS cap and render simplification can take effect.
