# Build trên PC

1. Mở project `WLZ_Client` bằng Android Studio.
2. Chờ Gradle Sync.
3. Vào Build -> Build APK(s).
4. Lấy `app/build/outputs/apk/debug/app-debug.apk`.
5. Đổi tên thành `WLZ-Client.apk`.

Hoặc push project lên GitHub và chạy workflow `Build WLZ Client` để lấy artifact `WLZ-Client-debug-arm64`.
