# WLZ target

Package: com.mojang.minecraftpe
Version: 1.26.51.1
Version code: 982605101
ABI: arm64-v8a
Minimum Android target for WLZ: API 28

Use the user's own Minecraft installation for testing. Do not redistribute Minecraft's proprietary binary.
