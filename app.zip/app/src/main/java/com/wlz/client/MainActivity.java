package com.wlz.client;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SeekBar;

import java.util.LinkedHashMap;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final String MC_PACKAGE = "com.mojang.minecraftpe";
    private static final String PREFS = "wlz_settings";
    private static final int MODULES = 10;

    // WLZ v0.4 palette: orange / graphite gray / moss green.
    private static final int BG = Color.rgb(11, 17, 15);
    private static final int PANEL = Color.rgb(18, 27, 23);
    private static final int PANEL_2 = Color.rgb(23, 33, 28);
    private static final int GRAPHITE = Color.rgb(47, 54, 51);
    private static final int MOSS = Color.rgb(100, 119, 66);
    private static final int MOSS_DARK = Color.rgb(48, 63, 43);
    private static final int ORANGE = Color.rgb(239, 112, 18);
    private static final int ORANGE_LIGHT = Color.rgb(255, 153, 51);
    private static final int TEXT = Color.rgb(241, 239, 231);
    private static final int MUTED = Color.rgb(164, 171, 163);

    private final Map<String, ModuleDef> modules = new LinkedHashMap<>();
    private SharedPreferences prefs;
    private TextView status;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        defineModules();
        try { RuntimeBridge.nativeIsLoaded(); } catch (Throwable ignored) {}
        setContentView(buildUi());
    }

    private void defineModules() {
        modules.clear();
        add("Zoom", "Giữ để phóng camera", 0);
        add("FreeLook", "Xoay góc nhìn độc lập", 1);
        add("Ném đồ", "Thao tác drop nhanh", 2);
        add("Unlock FPS", "Ưu tiên bỏ giới hạn FPS", 3);
        add("Fullbright", "Tăng mức sáng", 4);
        add("Hitbox", "Hiện vùng va chạm entity", 5);
        add("AutoSprint", "Tự chạy khi di chuyển", 6);
        add("Snaplook", "Xoay nhanh theo góc định sẵn", 7);
        add("FPS Counter", "Hiện bộ đếm FPS", 8);
        add("Super Fix Lag", "Giảm độ phức tạp render", 9);
    }

    private void add(String name, String desc, int index) {
        modules.put(name, new ModuleDef(name, desc, index));
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.setBackgroundColor(BG);

        root.addView(header(), lp(-1, -2));
        root.addView(heroCard(), top(10));

        status = cardText("Đang kiểm tra Minecraft…", 13, MOSS, true);
        LinearLayout.LayoutParams sLp = lp(-1, -2); sLp.topMargin = dp(8); root.addView(status, sLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        Button launch = actionButton("▶  BẮT ĐẦU", ORANGE, TEXT);
        launch.setOnClickListener(v -> launchMinecraft());
        actions.addView(launch, new LinearLayout.LayoutParams(0, dp(50), 1));
        Button overlay = actionButton("☷  OVERLAY", MOSS_DARK, TEXT);
        overlay.setOnClickListener(v -> openOverlaySettings());
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(0, dp(50), 1); olp.leftMargin = dp(8);
        actions.addView(overlay, olp);
        root.addView(actions, top(9));

        LinearLayout pack = new LinearLayout(this);
        pack.setGravity(Gravity.CENTER_VERTICAL);
        pack.setPadding(dp(12), dp(9), dp(12), dp(9));
        pack.setBackground(round(PANEL_2, GRAPHITE, 1, 12));
        TextView packTitle = text("PACK CENTER", 13, TEXT, true);
        TextView packSub = text("Chuẩn bị khu quản lý .mcpack / .mcaddon", 10, MUTED, false);
        LinearLayout pc = new LinearLayout(this); pc.setOrientation(LinearLayout.VERTICAL);
        pc.addView(packTitle); pc.addView(packSub);
        pack.addView(pc, new LinearLayout.LayoutParams(0, -2, 1));
        Button packBtn = smallButton("MỞ");
        packBtn.setOnClickListener(v -> Toast.makeText(this, "Pack Center sẽ được nối vào Minecraft ở bản runtime tiếp theo.", Toast.LENGTH_SHORT).show());
        pack.addView(packBtn, lp(-2, -2));
        root.addView(pack, top(8));

        TextView heading = text("MODULES  •  10", 14, TEXT, true);
        heading.setPadding(dp(3), dp(13), 0, dp(7));
        root.addView(heading, lp(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (ModuleDef module : modules.values()) list.addView(moduleRow(module));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView foot = text("WLZ Client v0.4  •  Orange / Graphite / Moss  •  ARM64", 10, MUTED, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(8), 0, 0);
        root.addView(foot, lp(-1, -2));

        refreshStatus();
        return root;
    }

    private View header() {
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("WLZ", 31, ORANGE, true);
        logo.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC));
        h.addView(logo, lp(-2, -2));
        TextView title = text("  CLIENT", 20, TEXT, true);
        h.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView chip = text("v0.4  •  ARM64", 10, MOSS, true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(9), dp(6), dp(9), dp(6));
        chip.setBackground(round(MOSS_DARK, MOSS, 1, 20));
        h.addView(chip, lp(-2, -2));
        return h;
    }

    private View heroCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(14), dp(15), dp(14));
        card.setBackground(round(PANEL, ORANGE, 1, 16));

        TextView t = text("PLAY SMARTER — NOT HARDER", 11, ORANGE_LIGHT, true);
        card.addView(t, lp(-1, -2));
        TextView main = text("WLZ Client", 26, TEXT, true);
        card.addView(main, top(3));
        TextView sub = text("Minecraft Bedrock 1.26.51.1  •  Android 9+", 12, MUTED, false);
        card.addView(sub, top(2));

        LinearLayout tags = new LinearLayout(this);
        tags.setPadding(0, dp(9), 0, 0);
        tags.addView(tag("CAM").view, new LinearLayout.LayoutParams(0, dp(30), 1));
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, dp(30), 1); b.leftMargin = dp(6);
        tags.addView(tag("XÁM").view, b);
        LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(0, dp(30), 1); c.leftMargin = dp(6);
        tags.addView(tag("RÊU").view, c);
        card.addView(tags);
        return card;
    }

    private Tag tag(String label) {
        TextView v = text(label, 10, TEXT, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(round(label.equals("CAM") ? ORANGE : label.equals("XÁM") ? GRAPHITE : MOSS_DARK,
                label.equals("CAM") ? ORANGE_LIGHT : MOSS, 1, 10));
        return new Tag(v);
    }
    private static final class Tag { final TextView view; Tag(TextView v){view=v;} }

    private View moduleRow(ModuleDef module) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(10), dp(10), dp(9));
        row.setBackground(round(PANEL_2, GRAPHITE, 1, 13));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView dot = text("●", 14, module.index % 3 == 0 ? ORANGE : MOSS, true);
        head.addView(dot, new LinearLayout.LayoutParams(dp(24), -2));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(text(module.name, 14, TEXT, true), lp(-1, -2));
        copy.addView(text(module.desc, 10, MUTED, false), lp(-1, -2));
        head.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));

        Switch sw = new Switch(this);
        sw.setButtonTintList(null);
        boolean checked = prefs.getBoolean(module.key(), false);
        sw.setChecked(checked);
        syncNative(module.index, checked);
        sw.setOnCheckedChangeListener((CompoundButton b, boolean c) -> {
            prefs.edit().putBoolean(module.key(), c).apply();
            syncNative(module.index, c);
        });
        head.addView(sw, lp(-2, -2));
        row.addView(head, lp(-1, -2));

        if (module.index == 0) addSlider(row, "Zoom", 100, 400, prefs.getInt("zoom_pct", 150), v -> {
            prefs.edit().putInt("zoom_pct", v).apply(); setNativeParam(0, v);
        });
        if (module.index == 3) addSlider(row, "FPS mục tiêu", 30, 240, prefs.getInt("fps_target", 60), v -> {
            prefs.edit().putInt("fps_target", v).apply(); setNativeParam(1, v);
        });
        if (module.index == 4) addSlider(row, "Sáng", 50, 300, prefs.getInt("fullbright_pct", 100), v -> {
            prefs.edit().putInt("fullbright_pct", v).apply(); setNativeParam(2, v);
        });
        if (module.index == 9) addSlider(row, "Mức giảm render", 1, 3, prefs.getInt("lag_profile", 1), v -> {
            prefs.edit().putInt("lag_profile", v).apply(); setNativeParam(3, v);
        });

        LinearLayout.LayoutParams wrap = lp(-1, -2); wrap.bottomMargin = dp(7); row.setLayoutParams(wrap);
        return row;
    }

    private void addSlider(LinearLayout parent, String label, int min, int max, int value, ValueSetter setter) {
        TextView t = text(label + ": " + value, 10, MUTED, false);
        parent.addView(t, top(4));
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(Math.max(0, Math.min(max - min, value - min)));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                int v = min + p; t.setText(label + ": " + v); if (fromUser) setter.set(v);
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        parent.addView(bar, lp(-1, -2));
    }

    private void syncNative(int index, boolean enabled) { try { RuntimeBridge.nativeSetModule(index, enabled); } catch (Throwable ignored) {} }
    private void setNativeParam(int key, int value) { try { RuntimeBridge.nativeSetParam(key, value); } catch (Throwable ignored) {} }

    private void resetModules() {
        SharedPreferences.Editor e = prefs.edit();
        for (ModuleDef m : modules.values()) { e.putBoolean(m.key(), false); syncNative(m.index, false); }
        e.apply(); recreate();
    }

    private void launchMinecraft() {
        Intent intent = getPackageManager().getLaunchIntentForPackage(MC_PACKAGE);
        if (intent == null) { Toast.makeText(this, "Không tìm thấy Minecraft (com.mojang.minecraftpe)", Toast.LENGTH_LONG).show(); return; }
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED));
    }

    private void openOverlaySettings() {
        try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)); }
    }

    private void refreshStatus() {
        if (status == null) return;
        boolean installed = getPackageManager().getLaunchIntentForPackage(MC_PACKAGE) != null;
        status.setText(installed ? "●  Minecraft đã được phát hiện  •  Sẵn sàng" : "●  Chưa tìm thấy Minecraft");
        status.setTextColor(installed ? MOSS : ORANGE);
    }
    @Override protected void onResume() { super.onResume(); refreshStatus(); }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView tv = new TextView(this); tv.setText(value); tv.setTextSize(sp); tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return tv;
    }
    private TextView cardText(String v, float sp, int c, boolean b) {
        TextView t = text(v, sp, c, b); t.setPadding(dp(12), dp(10), dp(12), dp(10)); t.setBackground(round(PANEL, MOSS, 1, 12)); return t;
    }
    private Button actionButton(String s, int bg, int fg) {
        Button b = new Button(this); b.setText(s); b.setTextColor(fg); b.setTextSize(12); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(bg, bg == ORANGE ? ORANGE_LIGHT : MOSS, 1, 13)); return b;
    }
    private Button smallButton(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(TEXT); b.setTextSize(11); b.setAllCaps(false); b.setBackground(round(MOSS_DARK, MOSS, 1, 10)); return b;
    }
    private GradientDrawable round(int fill, int stroke, int width, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(fill); d.setCornerRadius(dp(radius)); d.setStroke(dp(width), stroke); return d;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private LinearLayout.LayoutParams top(int m) { LinearLayout.LayoutParams p = lp(-1, -2); p.topMargin = dp(m); return p; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private interface ValueSetter { void set(int v); }
    private static final class ModuleDef {
        final String name, desc; final int index;
        ModuleDef(String n, String d, int i) { name = n; desc = d; index = i; }
        String key() { return "m_" + index; }
    }
}
